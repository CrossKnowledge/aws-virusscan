#!/usr/bin/env ruby

require 'daemons'

Daemons.run(__dir__ + '/test.rb', {:monitor => true})
